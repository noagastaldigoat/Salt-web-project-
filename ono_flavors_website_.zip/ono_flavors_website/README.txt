ONO FLAVORS HAWAIʻI — WEBSITE CONCEPT

Open index.html in a browser to preview the static responsive prototype.

Updated in this pass:
- Replaced the alpine mountain direction on the story header with a Hawaiian coastal visual direction.
- Updated the story image to a salt-related editorial image placeholder.
- Improved mobile story-hero spacing and image order.
- Added Facebook, Instagram, and email links in the footer and contact page.
- Social links currently open search pages because official profile URLs could not be verified.

IMPORTANT BEFORE LAUNCH:
- This is a concept prototype, not a production store.
- Product names, descriptions, and prices currently in the pages are placeholders and must be replaced with the full verified client catalog. The official website blocked automated access during this update, so missing products were not invented.
- Confirm that onoflavors@gmail.com and (808) 868-1470 are current contact details.
- Replace image placeholders with client-approved photos and official logo.
- Connect cart checkout, contact form, and newsletter to real services before launch.
